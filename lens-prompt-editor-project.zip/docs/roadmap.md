# Roadmap
- Rich parser via LLM function-calling
- Social presets
- Uploads and progress
- Preview thumbnails
- Templates/overlays
