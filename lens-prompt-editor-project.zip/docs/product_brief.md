# Product Brief
Problem: Editors are powerful but slow for simple, declarative edits.
Users: Solo creators, marketers, recruiters.
Job: "Let me describe the edit in plain English and get a usable result."
Solution: Prompt -> plan -> ffmpeg execution.
