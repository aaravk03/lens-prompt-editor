# Architecture (MVP)
Parser (rule-based) -> Planner (ordered ops) -> Executor (ffmpeg) -> UI (Next.js) calling FastAPI endpoints.
