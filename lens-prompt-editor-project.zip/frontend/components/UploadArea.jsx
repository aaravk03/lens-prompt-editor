export default function UploadArea() {
  return (
    <div style={{ padding: 12, border: "1px dashed #ccc" }}>
      <p>Upload will be added in a future iteration.</p>
    </div>
  )
}
