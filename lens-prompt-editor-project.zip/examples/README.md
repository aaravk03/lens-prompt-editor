Place a small input.mp4 here to test. Optionally add sample.srt for captions.
